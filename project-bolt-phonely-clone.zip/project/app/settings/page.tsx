import SettingsPage from "@/components/settings/settings-page"

export default function Page() {
  return <SettingsPage />
}